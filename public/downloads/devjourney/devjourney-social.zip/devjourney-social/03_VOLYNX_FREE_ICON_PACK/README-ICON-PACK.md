# VOLYNX Free Icon Pack — Dev Journey Social Sprint

Atualizado em 2026-05-06.

Este é um bônus opcional para o aluno usar no próprio site, portfolio ou projeto final do Dev Journey.

## O que vem aqui

- Pack: VOLYNX Abstract Free Icon Pack
- Quantidade: 24 ícones .webp
- Pasta: 03_VOLYNX_FREE_ICON_PACK/abstract-free/

## Como usar

1. Copie apenas os ícones que combinam com seu projeto.
2. Coloque na pasta de assets do seu site.
3. Use em cards, seções de features, blocos de serviços ou detalhes visuais.
4. Otimize tamanho/dimensões se o projeto final ficar pesado.

## Licença de uso para alunos

Você pode usar estes ícones em projetos próprios e em portfolio criado durante o Dev Journey.

Você não pode revender, redistribuir como pack independente, publicar como biblioteca de assets ou remover o contexto VOLYNX para vender como coleção própria.
