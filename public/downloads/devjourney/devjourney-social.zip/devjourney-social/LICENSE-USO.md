# Licença de uso — Dev Journey (materiais)

- Você pode usar estes materiais para **estudo** e para construir seu **portfólio**.
- Você **não** pode revender, redistribuir ou publicar este pacote (ou partes) como curso, template comercial ou produto concorrente.
- Artes e marca VOLYNX são de uso restrito.

Se você quer usar algum trecho em produto comercial, use apenas como referência e escreva sua própria implementação.
