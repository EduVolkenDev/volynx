# Brand assets — Dev Journey Social Sprint

Atualizado em 2026-05-06.

Esta pasta contém os assets visuais oficiais do Dev Journey aprovados para este pacote.

## Arquivos inclusos

- new-devjourney-asset.webp: Official Dev Journey course asset
- digitalpresence.webp: Digital Presence bonus visual

## Como usar

- Use o new-devjourney-asset.webp como capa, hero ou imagem de apresentação do curso.
- Use o digitalpresence.webp como bônus visual para páginas sobre presença digital, serviços ou portfolio.
- Se precisar de ícones para o próprio site, use o pack opcional em 03_VOLYNX_FREE_ICON_PACK/.

## Cuidados

- Nao distorça a proporção dos assets.
- Nao revenda, redistribua ou empacote esses assets como biblioteca independente.
- Em projeto de portfólio, mantenha a marca como referência educacional do Dev Journey, não como se a VOLYNX fosse dona do seu projeto.
