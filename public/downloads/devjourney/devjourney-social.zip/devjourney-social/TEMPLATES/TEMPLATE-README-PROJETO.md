# Nome do Projeto

## O que é
1–2 frases.

## Como rodar
- Abra `index.html` no navegador **ou** use Live Server (VS Code).

## Deploy
- Link:

## Checklist
- [ ] Funciona no desktop
- [ ] Funciona no mobile
- [ ] Não tem erro no Console
