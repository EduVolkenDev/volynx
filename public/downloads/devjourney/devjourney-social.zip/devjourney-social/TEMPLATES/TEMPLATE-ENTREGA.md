# TEMPLATE — Entrega (copiar e preencher)

## Identificação
- Nome:
- GitHub:
- Bloco: (1 ou 2)
- Aula:

## Link do projeto publicado
- URL:

## Repositório
- URL do GitHub:

## Checklist do que foi entregue
- [ ] Projeto abre e funciona
- [ ] README tem: o que é / como rodar / link de deploy
- [ ] Commit(s) com progresso real (não tudo em 1 commit)

## Evidência (quando fizer sentido)
- Print(s):

## Autoavaliação (2 linhas)
- O que eu entendi bem:
- Onde eu travei:
