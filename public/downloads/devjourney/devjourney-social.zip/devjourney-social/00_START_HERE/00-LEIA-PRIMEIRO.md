# Comece aqui — Dev Journey Social Sprint

Atualizado em 2026-05-06.

Bem-vindo ao Dev Journey dentro da VOLYNX.

A VOLYNX já está no ar, então a fonte oficial do curso agora é a plataforma:

- Área do aluno: https://volynx.world/dev-journey/student/
- Checklist online: https://volynx.world/dev-journey/checklist/
- Página do curso: https://volynx.world/dev-journey/
- Recuperação de compras/downloads: https://volynx.world/delivery/
- Suporte: https://volynx.world/support/

## Antes de estudar

1. Entre na sua conta VOLYNX.
2. Abra a Área do Aluno.
3. Baixe o ZIP correto para seu tier.
4. Leia este arquivo antes dos PDFs.
5. Siga o arquivo 01-ORDEM-DE-ESTUDO.md.
6. Rode o setup pelo arquivo 02-SETUP-ATUALIZADO.md.
7. Use o checklist online para marcar apenas o que realmente funciona na tela.

## Fonte de verdade

Se algum PDF antigo ou material dentro do ZIP mencionar um fluxo diferente, Hotmart, formulário já ativo ou outro caminho legado, considere este arquivo e a Área do Aluno como a versão atual.

O Dev Journey é autoguiado, mas não é solto: você trabalha com arquivos, checklists, projeto publicado e revisão manual quando a etapa de submissão estiver ativa.

## Status atual

- Social Sprint: grátis com login.
- Pro e Bundle: liberados por tier da conta.
- Progresso: salvo no checklist online quando você está logado.
- Downloads: feitos pelo vault da Área do Aluno.
- Certificação: revisão manual. A automação completa de validação entra em fase pós-lançamento.
- Submissão formal: a Área do Aluno mostra o status atual. Se estiver marcada como Fase 2, mantenha repo + URL live prontos e use o suporte quando precisar solicitar revisão.
