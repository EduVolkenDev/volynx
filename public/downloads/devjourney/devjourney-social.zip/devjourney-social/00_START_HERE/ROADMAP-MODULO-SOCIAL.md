# Roadmap — Módulo SOCIAL (Blocos 1 e 2)

## Resultado final do módulo (o que você vai ter no portfólio)
- **1 página apresentável** (HTML + CSS) publicada
- **1 mini app** com JavaScript (DOM + validações + JSON) publicado

## Bloco 1 — HTML + CSS
Saída esperada:
- Página com `header/main/footer`
- Tipografia e espaçamentos coerentes
- Um componente “card” reutilizável

Entrega mínima (passa):
- `index.html` + `style.css`
- layout legível no mobile e desktop

## Bloco 2 — JavaScript na prática
Saída esperada:
- Validação de input (número e formulário)
- Lista dinâmica com remover item
- Carregar e renderizar um `projetos.json` usando `fetch`

Entrega mínima (passa):
- Projeto rodando via Live Server
- Deploy publicado + README
