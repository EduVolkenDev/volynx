# Ordem de estudo — Dev Journey Social Sprint

Atualizado em 2026-05-06.

## Ordem recomendada — Social Sprint

1. Bloco 0: setup, conta VOLYNX, GitHub e checklist.
2. Bloco 1: HTML + CSS + primeiro comportamento visível.
3. Bloco 2: JavaScript, DOM, validação e JSON.
4. Publicação: suba o projeto em GitHub Pages, Netlify, Vercel ou outro host estático.
5. Registro: mantenha repo, URL live e README prontos para revisão manual.

## Regra principal

Nao marque uma etapa como pronta porque voce "leu". Marque quando existir algo funcionando na tela, com repo organizado e sem erro no Console.

## Rotina segura por bloco

1. Leia o objetivo do bloco.
2. Abra o starter certo.
3. Rode localmente.
4. Faça uma mudança pequena.
5. Veja funcionar na tela.
6. Faça commit.
7. Atualize README quando tiver algo publicável.
8. Marque o checklist online.

## Onde está cada coisa neste ZIP

- 00_START_HERE/: comece por aqui. Os arquivos Markdown atualizados valem mais do que qualquer instrução antiga.
- 01_SOCIAL/DOCS/: PDFs e glossários dos Blocos 1 e 2.
- 01_SOCIAL/PROJECTS/: starters dos projetos Social.
- 02_BRAND_ASSETS/: logos VOLYNX/Dev Journey 2026 e guia de uso.
- TEMPLATES/: modelos de README e entrega.

## Quando travar

Use a regra dos 20 minutos:

1. Volte um passo.
2. Rode o exemplo original.
3. Compare arquivo por arquivo.
4. Leia o erro no Console/Terminal.
5. Se ainda travar, anote o erro exato e mande no suporte.
