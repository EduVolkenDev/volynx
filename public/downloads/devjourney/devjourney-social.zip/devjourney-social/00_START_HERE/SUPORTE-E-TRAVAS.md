# Suporte — quando travar (sem drama)

## Regra dos 20 minutos
Travou por **20 minutos**:
1) volte 1 passo
2) replique o exemplo
3) compare linha por linha
4) avance de novo

## Erros campeões (e correção rápida)
### 1) “Nada mudou no navegador”
- salvou o arquivo? (Ctrl/Cmd+S)
- atualizou a página? (Ctrl/Cmd+R)
- abriu o arquivo certo? (index.html correto)

### 2) “Meu JS não roda”
- `script.js` está na **mesma pasta** do `index.html`?
- o HTML tem `<script src="script.js" defer></script>` **antes** de `</body>`?
- veja o **Console** (Inspecionar → Console)

### 3) “Fetch do JSON deu erro”
- arquivos precisam estar no mesmo servidor.
- solução simples: use **Live Server** no VS Code.

### 4) “Erro de caminho/arquivo não encontrado”
- maiúsculas e minúsculas importam em alguns sistemas.
- evite espaços e acentos em nomes de pastas do projeto.
