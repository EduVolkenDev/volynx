# Checklist — Módulo SOCIAL

## Bloco 1 (HTML + CSS)
- [ ] Tenho `index.html` com `header`, `main`, `footer`
- [ ] Sei explicar o que é: tag, atributo, classe, id
- [ ] Tenho um CSS com: tipografia, espaçamento, borda/radius
- [ ] Minha página está legível no mobile (texto não estoura, não some)
- [ ] Publiquei o projeto (GitHub Pages/Netlify/Vercel) e tenho o link
- [ ] README mínimo pronto (ver `TEMPLATES/`)

## Bloco 2 (JavaScript)
- [ ] Conectei `script.js` no HTML com `defer`
- [ ] Tenho validação de número (aceita vírgula/ponto) e mostro feedback
- [ ] Tenho validação de formulário e mensagem clara
- [ ] Tenho lista dinâmica (cria e remove item)
- [ ] Carrego `projetos.json` com `fetch` e renderizo na tela
- [ ] Rodei com Live Server (sem erro de CORS/arquivo)
- [ ] Publiquei o projeto e tenho o link

## Pronto para avançar quando
- [ ] Consigo repetir o Bloco 1 do zero sem copiar tudo
- [ ] Consigo explicar por que `fetch` precisa de servidor
- [ ] Consigo ler erro no Console e corrigir o básico
