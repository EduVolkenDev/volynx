# Notas de qualidade (padrão VOLYNX)

## Padrão de organização
- 1 pasta por projeto
- arquivos nomeados de forma limpa
- sem arquivos do sistema: `.DS_Store`, `__MACOSX`

## Padrão de entrega
- deploy publicado
- README mínimo (use o template)
- Console sem erros

## Nível de exigência
- "funciona" > "perfeito"
- consistência > estética
- progresso contínuo > maratona
