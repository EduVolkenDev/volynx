# Aula 0.3 — Setup (iniciante total)

Meta: deixar seu computador pronto para acompanhar o curso sem travar. Você não precisa “saber terminal” para começar — vamos por etapas.

## Checklist (marque aqui na página)
- [ ] Instalei um editor (recomendado: VS Code)
- [ ] Instalei o Node.js (LTS) e o npm está funcionando
- [ ] Instalei o Git e configurei nome/e-mail
- [ ] Criei minha conta no GitHub e verifiquei o e-mail
- [ ] Criei a pasta VOLYNX/DevJourney e organizei as subpastas

## Passo 1 — Instalar um editor (VS Code recomendado)
Baixe: https://code.visualstudio.com/download  
Verificação: o VS Code abre normalmente.

## Passo 2 — Instalar o Node.js (LTS)
Baixe: https://nodejs.org/en/download

Abra o Terminal/PowerShell:
- Windows: procure “PowerShell”
- macOS: abra “Terminal”
- Linux: abra “Terminal”

Cole e execute:
```bash
node -v
npm -v
```

## Passo 3 — Instalar o Git
Instale: https://git-scm.com/downloads  
Verificação:
```bash
git --version
```

## Passo 4 — Configurar o Git (uma vez só)
Troque pelos seus dados:
```bash
git config --global user.name "SEU NOME"
git config --global user.email "SEU EMAIL"
git config --global init.defaultBranch main
```

Conferir:
```bash
git config --global --list
```

## Passo 5 — Criar conta no GitHub
Crie aqui: https://github.com/join  
Depois, verifique o e-mail.

## Passo 6 — Criar a pasta do curso (jeito fácil)
No “Documentos / Documents” crie:
- VOLYNX
  - DevJourney
    - 00-start-here
    - 01-fundamentos
    - 02-js-dom
    - 03-react
    - 04-backend
    - 05-integracao-deploy
    - projetos
      - landing-premium
      - app-web
      - projeto-final

## Health-check final (1 linha)
Rode e confirme que aparecem versões:
```bash
node -v && npm -v && git --version
```

Se deu certo, clique em **Concluir aula** e avance.
