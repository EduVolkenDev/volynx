# Errata (ajustes rápidos recomendados)

## Glossário — Bloco 1
- `initialscale` → **`initial-scale`** (na meta viewport)
- `spacebetween` → **`space-between`** (no `justify-content`)

## Setup PDF
- O comando `mkdir -p ... { ... }` aparece quebrado por quebra de linha no PDF.
  - Recomenda-se o aluno copiar do arquivo `00_START_HERE/SETUP.md` (este é copiar/colar).
