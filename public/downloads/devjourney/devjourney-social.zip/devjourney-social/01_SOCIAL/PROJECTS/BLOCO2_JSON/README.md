# Bloco 2 — Project JSON

## Objetivo
Praticar:
- validação (número e formulário)
- DOM (criar/remover itens)
- fetch + JSON (carregar arquivo e renderizar)

## Como rodar (importante)
Para o `fetch("./projetos.json")` funcionar sem bloqueios, rode com **Live Server** no VS Code.

## Entrega
- Deploy publicado
- Provar que lista do JSON aparece
- README mínimo (ver template em `TEMPLATES/`)
