# Bloco 1 — Starter Project

## Objetivo
Praticar estrutura HTML, CSS básico e eventos simples com JavaScript.

## Como rodar
- Abra `index.html` no navegador
- Alternativa: use Live Server (VS Code)

## O que você deve conseguir fazer
- Trocar tema (variáveis CSS)
- Validar input e mostrar feedback na tela

## Entrega
- Deploy publicado + README mínimo (ver template em `TEMPLATES/`)
