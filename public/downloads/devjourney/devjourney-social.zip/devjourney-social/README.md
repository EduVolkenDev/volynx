# Dev Journey — Social Sprint

Bem-vindo ao Dev Journey Social Sprint pela VOLYNX.

Este pacote contém:
- 00_START_HERE/ — guias de boas-vindas, requisitos, setup e regras de certificação
- 01_SOCIAL/ — Bloco 1 (HTML/CSS/JS), Bloco 2 (DOM/JSON), glossários e projetos starter
- 02_BRAND_ASSETS/ — arte oficial pra você usar nos seus projetos
- TEMPLATES/ — templates de README de projeto e entrega

## Como funciona

1. Comece pelo `00_START_HERE/COMO-USAR-O-CURSO.pdf`
2. Siga `ROADMAP-MODULO-SOCIAL.md`
3. Use o checklist em `CHECKLIST-MODULO-SOCIAL.md` (ou na área do aluno em https://volynx.world/dev-journey/checklist/)
4. Quando terminar, submeta o projeto pelo formulário online — a certificação é por revisão manual

## Suporte

- Área do aluno: https://volynx.world/dev-journey/student/
- Suporte: https://volynx.world/support/

## Próximos passos

Ao terminar o Social, você pode subir pra **Pro** (Bloco 3 — React App) ou **Bundle** (Blocos 4-5 + Arsenal Kit). Compare em https://volynx.world/dev-journey/#upgrade

---

VOLYNX • Building a Smarter Future
