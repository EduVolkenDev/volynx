# Dev Journey — Social Sprint

Bem-vindo ao Dev Journey Social Sprint pela VOLYNX.

Este pacote contém:
- 00_START_HERE/ — Comece Aqui atualizado, setup, ordem de estudo e regras de certificação
- 01_SOCIAL/ — Bloco 1 (HTML/CSS/JS), Bloco 2 (DOM/JSON), glossários e projetos starter
- 02_BRAND_ASSETS/ — new-devjourney-asset, digitalpresence e guia de uso
- 03_VOLYNX_FREE_ICON_PACK/ — pack opcional de ícones para site/portfólio
- TEMPLATES/ — templates de README de projeto e entrega

## Como funciona

1. Comece por `00_START_HERE/00-LEIA-PRIMEIRO.md`
2. Siga `00_START_HERE/01-ORDEM-DE-ESTUDO.md`
3. Rode o setup por `00_START_HERE/02-SETUP-ATUALIZADO.md`
4. Use o checklist online em https://volynx.world/dev-journey/checklist/
5. Quando terminar, envie repo + URL live pela Área do Aluno e corrija qualquer requisito indicado pelo validador.

## Suporte

- Área do aluno: https://volynx.world/dev-journey/student/
- Suporte: https://volynx.world/support/

## Próximos passos

Ao terminar o Social, você pode subir pra **Pro** (Bloco 3 — React App) ou **Bundle** (Blocos 4-5 + Arsenal Kit). Compare em https://volynx.world/dev-journey/#upgrade

---

VOLYNX • Building a Smarter Future
