# Setup atualizado — Dev Journey

Atualizado em 2026-05-06.

Este arquivo existe para evitar problema de instrução antiga. Use ele como checklist principal de setup.

## Ferramentas essenciais

- Navegador moderno: Chrome, Edge, Firefox ou Safari atualizado.
- Editor: VS Code recomendado.
- Extensão útil no VS Code: Live Server.
- Conta GitHub com email verificado.
- Git instalado.
- Node.js LTS instalado para Pro/Bundle e para qualquer projeto com Vite.

## Health check no terminal

Rode:

    node -v
    npm -v
    git --version

Se algum comando nao aparecer, instale ou reinstale a ferramenta correspondente antes de avançar.

## Git — configuração inicial

Troque pelos seus dados:

    git config --global user.name "SEU NOME"
    git config --global user.email "SEU EMAIL"
    git config --global init.defaultBranch main

Conferir:

    git config --global --list

## Organização recomendada

Crie uma pasta simples, sem acentos e sem espaços:

    VOLYNX/DevJourney/

Dentro dela, use uma pasta por projeto:

    bloco-1-fundamentos/
    bloco-2-dom-json/
    bloco-3-react-app/
    bloco-4-api/
    bloco-5-deploy/
    projeto-final/

## Rodando projetos HTML/CSS/JS

Para arquivos simples, abra com Live Server no VS Code.

Se o projeto usa fetch para carregar JSON, nao abra direto como file://. Use Live Server, Vite ou outro servidor local.

## Rodando projetos React/Vite

Dentro da pasta do projeto:

    npm install
    npm run dev

Abra a URL que o terminal mostrar, normalmente http://localhost:5173/.

## Antes de publicar

- Console do navegador sem erro vermelho.
- Layout legível no mobile.
- README com o que é, como rodar, link do deploy e link do repo.
- Commits com progresso real.
- URL live abrindo em aba anônima.
