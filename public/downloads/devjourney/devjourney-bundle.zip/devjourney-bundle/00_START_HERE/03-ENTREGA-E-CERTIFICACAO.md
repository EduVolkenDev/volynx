# Entrega, revisão e certificação

Atualizado em 2026-05-06.

## O que preparar

Para a validação, deixe pronto:

- Nome completo usado na conta VOLYNX.
- Email da conta VOLYNX.
- Tier do Dev Journey: Social, Pro ou Bundle.
- Link do repositório GitHub.
- Link do projeto publicado.
- README atualizado.
- Checklist online marcado apenas com itens que funcionam.
- Observação curta dizendo onde você travou ou o que quer que seja revisado.

## Como a validação funciona

1. Envie um repositório público do GitHub e a URL HTTPS publicada.
2. O sistema verifica README.md, workflow em `.github/workflows/`, uma execução concluída com sucesso e a resposta da URL publicada.
3. Se algo falhar, o resultado volta com a correção exata necessária.
4. Quando tudo passar, a Área do Aluno mostra o ID e o fingerprint do certificado verificável.

## Critério mínimo de revisão

- Projeto abre.
- Projeto funciona no navegador.
- Não há erro crítico no Console.
- README explica como rodar.
- Link publicado funciona fora da sua máquina.
- O que foi marcado no checklist aparece no projeto.

## O que não conta como pronto

- Só print sem URL live.
- Repo vazio ou sem README.
- Projeto que só funciona na sua máquina.
- Erro no Console ignorado.
- Copiar arquivo sem conseguir explicar o básico do que ele faz.
