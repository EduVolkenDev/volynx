# Entrega, revisão e certificação

Atualizado em 2026-05-06.

## O que preparar

Para qualquer revisão manual, deixe pronto:

- Nome completo usado na conta VOLYNX.
- Email da conta VOLYNX.
- Tier do Dev Journey: Social, Pro ou Bundle.
- Link do repositório GitHub.
- Link do projeto publicado.
- README atualizado.
- Checklist online marcado apenas com itens que funcionam.
- Observação curta dizendo onde você travou ou o que quer que seja revisado.

## Status honesto da submissão

A certificação existe como revisão manual, mas a pipeline automática de validação está em fase pós-lançamento.

Se a Área do Aluno mostrar "Fase 2" ou "Em breve" no card de submissão, isso significa:

1. Continue estudando normalmente.
2. Publique o projeto.
3. Mantenha repo + URL live prontos.
4. Use o suporte se precisar solicitar revisão antes do formulário final estar ativo.

## Critério mínimo de revisão

- Projeto abre.
- Projeto funciona no navegador.
- Não há erro crítico no Console.
- README explica como rodar.
- Link publicado funciona fora da sua máquina.
- O que foi marcado no checklist aparece no projeto.

## O que não conta como pronto

- Só print sem URL live.
- Repo vazio ou sem README.
- Projeto que só funciona na sua máquina.
- Erro no Console ignorado.
- Copiar arquivo sem conseguir explicar o básico do que ele faz.
