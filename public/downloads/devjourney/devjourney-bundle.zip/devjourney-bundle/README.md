# Dev Journey — Bundle

Bem-vindo ao Dev Journey Bundle pela VOLYNX.

Este pacote contém:
- 00_START_HERE/ — Comece Aqui atualizado, compatibilidade, uso do curso e certificação
- 01_GLOSSARIOS/ — glossários dos blocos 1 e 2
- 02_BRAND_ASSETS/ — new-devjourney-asset, digitalpresence e guia de uso
- 03_VOLYNX_FREE_ICON_PACK/ — pack opcional de ícones para site/portfólio
- PDFs/ — materiais do Bloco 0 ao Bloco 5 + Arsenal Cheatcodes
- Projetos/Start-Projects/ — base dos blocos iniciais
- Projetos/ProBundle-Projects/ — React app, API Express e exemplo de deploy
- Arsenal/ — projetos reutilizáveis e bônus práticos

## Como usar

1. Comece por `00_START_HERE/00-LEIA-PRIMEIRO.md`
2. Siga `00_START_HERE/01-ORDEM-DE-ESTUDO.md`
3. Rode o setup por `00_START_HERE/02-SETUP-ATUALIZADO.md`
4. Siga a ordem natural dos PDFs: fundamentos, React, API e deploy
5. Abra os projetos de `Projetos/ProBundle-Projects/` conforme avançar
6. Use o `Arsenal/` como biblioteca prática para acelerar seus entregáveis
7. Ao finalizar, deixe repo + URL live prontos para revisão manual e certificação

## Suporte

- Área do aluno: https://volynx.world/dev-journey/student/
- Checklist: https://volynx.world/dev-journey/checklist/
- Suporte: https://volynx.world/support/

## Próximos passos

O Bundle já é a trilha completa. O foco daqui pra frente é publicar, validar e transformar os projetos em portfólio real.

---

VOLYNX • Building a Smarter Future
