Como usar:
1) Abra index.html no navegador.
2) Troque textos e seções.
3) Teste o formulário (validação + mensagem na tela).
