const form = document.getElementById("formContato");
const nome = document.getElementById("nome");
const msg = document.getElementById("msg");
const status = document.getElementById("status");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const n = nome.value.trim();
  const m = msg.value.trim();

  if (!n || !m) {
    status.textContent = "Preencha nome e mensagem.";
    return;
  }

  status.textContent = `Mensagem registrada. Obrigado(a), ${n}.`;
  nome.value = "";
  msg.value = "";
});
