const form = document.getElementById("leadForm");
const email = document.getElementById("email");
const status = document.getElementById("status");

function isEmail(v){
  const s = String(v).trim().toLowerCase();
  return s.includes("@") && s.includes(".") && s.length >= 6;
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const v = email.value.trim();
  if (!isEmail(v)) {
    status.textContent = "Digite um e-mail válido.";
    return;
  }

  const leads = JSON.parse(localStorage.getItem("leads") || "[]");
  leads.push({ email: v, ts: Date.now() });
  localStorage.setItem("leads", JSON.stringify(leads));

  status.textContent = "Registrado. Você pode ver em localStorage (DevTools).";
  email.value = "";
});
