Como usar:
1) Abra index.html.
2) Envie um e-mail.
3) Abra DevTools → Application → Local Storage → veja 'leads'.
