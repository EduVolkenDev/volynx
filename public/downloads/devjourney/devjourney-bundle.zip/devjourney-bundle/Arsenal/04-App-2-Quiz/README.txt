Como usar:
1) Abra index.html.
2) Responda o quiz.
3) Reiniciar para testar de novo.
