const perguntaEl = document.getElementById("pergunta");
const opcoesEl = document.getElementById("opcoes");
const statusEl = document.getElementById("status");
const placarEl = document.getElementById("placar");
const btnReiniciar = document.getElementById("btnReiniciar");

const perguntas = [
  { q: "O que o HTML define?", a: ["Estilo", "Estrutura", "Ação"], ok: 1 },
  { q: "Qual comparação evita conversão automática?", a: ["==", "=", "==="], ok: 2 },
  { q: "JSON é:", a: ["Banco de dados", "Formato de dados em texto", "Um framework"], ok: 1 },
];

let idx = 0;
let score = 0;
let locked = false;

function render() {
  locked = false;
  const p = perguntas[idx];
  perguntaEl.textContent = p.q;
  statusEl.textContent = "Escolha uma opção.";
  opcoesEl.innerHTML = "";
  p.a.forEach((txt, i) => {
    const b = document.createElement("button");
    b.textContent = txt;
    b.addEventListener("click", () => escolher(i, b));
    opcoesEl.appendChild(b);
  });
  placarEl.textContent = `Pergunta ${idx + 1}/${perguntas.length} • Pontos: ${score}`;
}

function escolher(i, btn) {
  if (locked) return;
  locked = true;

  const p = perguntas[idx];
  const correto = i === p.ok;
  btn.classList.add(correto ? "good" : "bad");
  statusEl.textContent = correto ? "Certo." : `Errado. Resposta: ${p.a[p.ok]}`;

  if (correto) score += 1;

  setTimeout(() => {
    idx += 1;
    if (idx >= perguntas.length) {
      perguntaEl.textContent = "Fim.";
      opcoesEl.innerHTML = "";
      statusEl.textContent = `Você fez ${score}/${perguntas.length}.`;
      placarEl.textContent = "";
      return;
    }
    render();
  }, 900);
}

btnReiniciar.addEventListener("click", () => {
  idx = 0;
  score = 0;
  render();
});

render();
