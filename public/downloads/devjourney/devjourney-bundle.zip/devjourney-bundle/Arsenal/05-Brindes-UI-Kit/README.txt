Brinde: VOLYNX UI Kit (CSS tokens + componentes).
Como usar:
1) Copie volynx-ui-kit.css para seu projeto.
2) No HTML: <link rel='stylesheet' href='volynx-ui-kit.css'>
3) Use classes: vlx-card, vlx-btn, vlx-grid.
