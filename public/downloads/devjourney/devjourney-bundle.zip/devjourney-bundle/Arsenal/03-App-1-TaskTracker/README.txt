Como usar:
1) Abra index.html.
2) Adicione tarefas.
3) Conclua/Desfaça.
4) Recarregue a página: dados continuam (LocalStorage).
