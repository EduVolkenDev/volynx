const form = document.getElementById("taskForm");
const titulo = document.getElementById("titulo");
const lista = document.getElementById("lista");
const contagem = document.getElementById("contagem");
const btnLimpar = document.getElementById("btnLimpar");

function load() {
  return JSON.parse(localStorage.getItem("tasks") || "[]");
}
function save(tasks) {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

let tasks = load();

function render() {
  lista.innerHTML = "";
  tasks.forEach((t) => {
    const li = document.createElement("li");
    li.className = "item";

    const left = document.createElement("div");
    const title = document.createElement("div");
    title.textContent = t.titulo;
    if (t.done) title.classList.add("done");

    const meta = document.createElement("div");
    meta.className = "badge";
    meta.textContent = t.done ? "concluída" : "pendente";

    left.appendChild(title);
    left.appendChild(meta);

    const btn = document.createElement("button");
    btn.textContent = t.done ? "Desfazer" : "Concluir";
    btn.className = "ghost";
    btn.addEventListener("click", () => {
      tasks = tasks.map((x) => (x.id === t.id ? { ...x, done: !x.done } : x));
      save(tasks);
      render();
    });

    li.appendChild(left);
    li.appendChild(btn);
    lista.appendChild(li);
  });

  const done = tasks.filter((t) => t.done).length;
  contagem.textContent = `Total: ${tasks.length} • Concluídas: ${done}`;
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const v = titulo.value.trim();
  if (v.length < 3) return;
  tasks = [{ id: Date.now(), titulo: v, done: false }, ...tasks];
  titulo.value = "";
  save(tasks);
  render();
});

btnLimpar.addEventListener("click", () => {
  tasks = tasks.filter((t) => !t.done);
  save(tasks);
  render();
});

render();
