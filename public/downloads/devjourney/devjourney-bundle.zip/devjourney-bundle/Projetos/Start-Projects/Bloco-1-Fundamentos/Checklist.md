# Checklist — Bloco 1

- [ ] Abri index.html no navegador e vi a página.
- [ ] O botão troca o tema (algo muda na tela).
- [ ] O formulário valida vazio e mostra mensagem.
- [ ] Alterei 1 coisa no HTML e confirmei no navegador.
- [ ] Alterei 1 coisa no CSS e confirmei no navegador.
- [ ] Alterei 1 coisa no JS e confirmei no navegador.
