const btnTema = document.getElementById("btnTema");
const titulo = document.getElementById("titulo");
const form = document.getElementById("formContato");
const nome = document.getElementById("nome");
const saida = document.getElementById("saida");

let dark = true;

btnTema.addEventListener("click", () => {
  dark = !dark;

  document.documentElement.style.setProperty("--bg", dark ? "#0b0b0c" : "#f5f5f7");
  document.documentElement.style.setProperty("--text", dark ? "#ffffff" : "#111827");
  document.documentElement.style.setProperty("--card", dark ? "rgba(255,255,255,.06)" : "rgba(17,24,39,.06)");
  document.documentElement.style.setProperty("--border", dark ? "rgba(255,255,255,.14)" : "rgba(17,24,39,.18)");
  document.documentElement.style.setProperty("--muted", dark ? "rgba(255,255,255,.72)" : "rgba(17,24,39,.72)");

  btnTema.textContent = dark ? "Trocar tema" : "Voltar para escuro";
  titulo.textContent = dark ? "Minha Primeira Página" : "Minha Página (Tema Claro)";
});

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const valor = nome.value.trim();
  if (valor === "") {
    saida.textContent = "Digite seu nome para enviar.";
    return;
  }
  saida.textContent = `Enviado! Olá, ${valor}.`;
  nome.value = "";
});
