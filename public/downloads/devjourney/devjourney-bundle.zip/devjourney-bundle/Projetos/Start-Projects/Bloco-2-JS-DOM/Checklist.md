# Checklist — Bloco 2

- [ ] Validei número com toNumber (aceita vírgula e ponto).
- [ ] Calculei desconto e mostrei o resultado na tela.
- [ ] Criei lista com DOM e removi item com clique.
- [ ] Validei um formulário e mostrei mensagem na tela.
- [ ] Carreguei um JSON e renderizei itens na tela.
