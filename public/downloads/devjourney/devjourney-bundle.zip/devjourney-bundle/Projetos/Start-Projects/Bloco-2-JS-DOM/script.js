const precoInput = document.getElementById("preco");
const descontoInput = document.getElementById("desconto");
const btnCalcular = document.getElementById("btnCalcular");
const saidaDesconto = document.getElementById("saidaDesconto");

function toNumber(valor) {
  const limpo = String(valor).trim().replace(",", ".");
  if (limpo === "") return null;
  const n = Number(limpo);
  if (Number.isNaN(n)) return null;
  return n;
}

function calcularDesconto(preco, porcentagem) {
  return preco - (preco * porcentagem) / 100;
}

btnCalcular.addEventListener("click", () => {
  const preco = toNumber(precoInput.value);
  const pct = toNumber(descontoInput.value);

  if (preco === null || pct === null) {
    saidaDesconto.textContent = "Digite números válidos (ex.: 19.90 e 15).";
    saidaDesconto.className = "bad";
    return;
  }
  if (pct < 0 || pct > 100) {
    saidaDesconto.textContent = "Desconto precisa estar entre 0 e 100.";
    saidaDesconto.className = "bad";
    return;
  }

  const final = calcularDesconto(preco, pct);
  saidaDesconto.textContent = `Preço final: R$ ${final.toFixed(2)}`;
  saidaDesconto.className = "ok";
});

const novoItem = document.getElementById("novoItem");
const btnAdd = document.getElementById("btnAdd");
const lista = document.getElementById("lista");

let projetos = [
  { titulo: "Página simples", tipo: "site" },
  { titulo: "Mini app", tipo: "app" },
];

function renderLista() {
  lista.innerHTML = "";
  projetos.forEach((p, i) => {
    const li = document.createElement("li");
    li.textContent = `${p.titulo} (${p.tipo})`;
    li.addEventListener("click", () => {
      projetos = projetos.filter((_, idx) => idx !== i);
      renderLista();
    });
    lista.appendChild(li);
  });
}

btnAdd.addEventListener("click", () => {
  const t = novoItem.value.trim();
  if (t === "") return;
  projetos.push({ titulo: t, tipo: "site" });
  novoItem.value = "";
  renderLista();
});

renderLista();

const formUser = document.getElementById("formUser");
const uNome = document.getElementById("uNome");
const uIdade = document.getElementById("uIdade");
const saidaUser = document.getElementById("saidaUser");

function isAdulto(idade) {
  return idade >= 18;
}

formUser.addEventListener("submit", (e) => {
  e.preventDefault();
  const nome = uNome.value.trim();
  const idade = toNumber(uIdade.value);

  if (nome === "" || idade === null) {
    saidaUser.textContent = "Preencha nome e idade válidos.";
    saidaUser.className = "bad";
    return;
  }

  saidaUser.textContent = isAdulto(idade)
    ? `OK, ${nome}: você é adulto(a).`
    : `OK, ${nome}: você ainda é menor de idade.`;
  saidaUser.className = "ok";
});

const btnCarregar = document.getElementById("btnCarregar");
const saidaJson = document.getElementById("saidaJson");

btnCarregar.addEventListener("click", async () => {
  saidaJson.innerHTML = "";
  try {
    const res = await fetch("./projetos.json");
    if (!res.ok) throw new Error("Falha ao carregar JSON.");
    const data = await res.json();
    data.forEach((p) => {
      const li = document.createElement("li");
      li.textContent = `${p.titulo} — ${p.tipo} — ${p.status}`;
      saidaJson.appendChild(li);
    });
  } catch (err) {
    const li = document.createElement("li");
    li.textContent = "Erro: " + err.message;
    saidaJson.appendChild(li);
  }
});
