import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

let projetos = [
  { id: 1, titulo: "Landing Premium", tipo: "site", status: "pronto" },
  { id: 2, titulo: "DevTracker", tipo: "app", status: "em progresso" },
];

app.get("/health", (_req, res) => res.json({ ok: true, ts: Date.now() }));
app.get("/projetos", (_req, res) => res.json(projetos));

app.post("/projetos", (req, res) => {
  const { titulo, tipo, status } = req.body ?? {};
  if (!titulo || String(titulo).trim().length < 3) {
    return res.status(400).json({ ok: false, error: "titulo inválido (mínimo 3 letras)" });
  }
  const novo = {
    id: Date.now(),
    titulo: String(titulo).trim(),
    tipo: tipo === "app" ? "app" : "site",
    status: status === "pronto" ? "pronto" : "em progresso",
  };
  projetos = [novo, ...projetos];
  return res.json({ ok: true, projeto: novo });
});

app.delete("/projetos/:id", (req, res) => {
  const id = Number(req.params.id);
  const antes = projetos.length;
  projetos = projetos.filter((p) => p.id !== id);
  return res.json({ ok: true, removed: antes - projetos.length });
});

const PORT = 3000;
app.listen(PORT, () => console.log(`API pronta: http://localhost:${PORT}`));
