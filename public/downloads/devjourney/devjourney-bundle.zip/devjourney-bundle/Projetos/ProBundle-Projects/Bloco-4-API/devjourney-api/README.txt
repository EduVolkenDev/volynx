Rodar:
1) npm install
2) node server.js
Testes:
- http://localhost:3000/health
- http://localhost:3000/projetos
