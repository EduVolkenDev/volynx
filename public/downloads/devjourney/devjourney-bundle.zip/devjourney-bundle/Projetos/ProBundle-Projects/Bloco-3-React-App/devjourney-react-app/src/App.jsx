import { useMemo, useState } from "react";

function Card({ titulo, tipo, status, onRemove }) {
  return (
    <div style={{ border:"1px solid #e5e7eb", borderRadius:14, padding:14, background:"white" }}>
      <h3 style={{ margin:0 }}>{titulo}</h3>
      <p style={{ margin:"6px 0", opacity:.75 }}>{tipo} • {status}</p>
      <button onClick={onRemove} style={{ padding:"8px 10px", borderRadius:12, border:"1px solid #111827", background:"#111827", color:"white", cursor:"pointer" }}>
        Remover
      </button>
    </div>
  );
}

export default function App() {
  const [items, setItems] = useState([
    { id: 1, titulo: "Landing Premium", tipo: "site", status: "pronto" },
    { id: 2, titulo: "DevTracker", tipo: "app", status: "em progresso" },
  ]);

  const [titulo, setTitulo] = useState("");
  const [msg, setMsg] = useState("");

  const total = useMemo(() => items.length, [items]);

  function addItem(e) {
    e.preventDefault();
    const t = titulo.trim();
    if (t.length < 3) { setMsg("Digite um título com 3+ letras."); return; }
    setItems(prev => [{ id: Date.now(), titulo: t, tipo: "site", status: "em progresso" }, ...prev]);
    setTitulo(""); setMsg("Adicionado.");
  }

  function removeItem(id) { setItems(prev => prev.filter(x => x.id !== id)); }

  async function loadFromApi() {
    setMsg("Carregando...");
    try {
      const r = await fetch("http://localhost:3000/projetos");
      if (!r.ok) throw new Error("API com erro");
      const data = await r.json();
      setItems(data);
      setMsg("Dados carregados da API.");
    } catch {
      const r = await fetch("/projetos.json");
      const data = await r.json();
      setItems(data.map((x,i)=>({ id:x.id ?? i+1, ...x })));
      setMsg("API não disponível. Carregado do JSON local.");
    }
  }

  return (
    <main style={{ fontFamily:"system-ui,Arial", background:"#f3f4f6", minHeight:"100vh" }}>
      <header style={{ padding:18, borderBottom:"1px solid #e5e7eb", background:"white", position:"sticky", top:0 }}>
        <h1 style={{ margin:0 }}>DevJourney — React App</h1>
        <p style={{ margin:"6px 0", opacity:.75 }}>Total: {total}</p>
        <div style={{ display:"flex", gap:10, flexWrap:"wrap" }}>
          <button onClick={loadFromApi} style={{ padding:"10px 12px", borderRadius:12, border:"1px solid #111827", background:"#111827", color:"white", cursor:"pointer" }}>
            Carregar (API/JSON)
          </button>
          <span style={{ opacity:.75 }}>{msg}</span>
        </div>
      </header>

      <section style={{ maxWidth:980, margin:"0 auto", padding:18 }}>
        <form onSubmit={addItem} style={{ display:"flex", gap:10, flexWrap:"wrap", background:"white", padding:14, border:"1px solid #e5e7eb", borderRadius:16 }}>
          <input value={titulo} onChange={(e)=>setTitulo(e.target.value)} placeholder="Título (3+ letras)" style={{ padding:"10px 12px", borderRadius:12, border:"1px solid #d1d5db", minWidth:260 }} />
          <button type="submit" style={{ padding:"10px 12px", borderRadius:12, border:"1px solid #111827", background:"#111827", color:"white", cursor:"pointer" }}>
            Adicionar
          </button>
        </form>

        <div style={{ display:"grid", gap:12, gridTemplateColumns:"repeat(auto-fit,minmax(240px,1fr))", marginTop:14 }}>
          {items.map(p => <Card key={p.id} {...p} onRemove={()=>removeItem(p.id)} />)}
        </div>
      </section>
    </main>
  );
}
