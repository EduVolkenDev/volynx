Rodar:
1) npm install
2) npm run dev
URL: http://localhost:5173
