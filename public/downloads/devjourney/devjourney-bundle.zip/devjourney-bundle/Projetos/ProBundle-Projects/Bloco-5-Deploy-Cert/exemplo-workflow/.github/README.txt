Copie .github/workflows/volynx-validate.yml para o seu repositório final.
