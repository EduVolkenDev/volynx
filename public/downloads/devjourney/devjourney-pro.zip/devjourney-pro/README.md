# Dev Journey — Pro Track

Bem-vindo ao Dev Journey Pro pela VOLYNX.

Este pacote contém:
- 00_START_HERE/ — Comece Aqui atualizado, compatibilidade, uso do curso e certificação
- 01_GLOSSARIOS/ — glossários dos blocos 1 e 2 para consulta rápida
- 02_BRAND_ASSETS/ — new-devjourney-asset, digitalpresence e guia de uso
- 03_VOLYNX_FREE_ICON_PACK/ — pack opcional de ícones para site/portfólio
- PDFs/ — materiais do Bloco 0 ao Bloco 3
- Projetos/Start-Projects/ — starters dos blocos iniciais
- Projetos/Bloco-3-React-App/ — projeto React incremental com Vite

## Como usar

1. Comece por `00_START_HERE/00-LEIA-PRIMEIRO.md`
2. Siga `00_START_HERE/01-ORDEM-DE-ESTUDO.md`
3. Rode o setup por `00_START_HERE/02-SETUP-ATUALIZADO.md`
4. Passe pelos PDFs do Bloco 0 antes de abrir o React starter
5. Use os projetos starter como base e evolua até o app React
6. Quando terminar, deixe repo + URL live prontos para revisão manual pela Área do Aluno/Suporte

## Suporte

- Área do aluno: https://volynx.world/dev-journey/student/
- Checklist: https://volynx.world/dev-journey/checklist/
- Suporte: https://volynx.world/support/

## Próximos passos

Ao concluir o Pro, o próximo nível é o **Bundle**, que libera Blocos 4-5, deploy/certificação e o Arsenal Kit.

---

VOLYNX • Building a Smarter Future
