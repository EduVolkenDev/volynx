# Dev Journey — Pro Track

Bem-vindo ao Dev Journey Pro pela VOLYNX.

Este pacote contém:
- 00_START_HERE/ — guias de entrada, compatibilidade, uso do curso e certificação
- 01_GLOSSARIOS/ — glossários dos blocos 1 e 2 para consulta rápida
- PDFs/ — materiais do Bloco 0 ao Bloco 3
- Projetos/Start-Projects/ — starters dos blocos iniciais
- Projetos/Bloco-3-React-App/ — projeto React incremental com Vite

## Como usar

1. Comece por `00_START_HERE/COMO-USAR-O-CURSO.pdf`
2. Passe pelos PDFs do Bloco 0 antes de abrir o React starter
3. Use os projetos starter como base e evolua até o app React
4. Quando terminar, submeta repo + URL live pela área do aluno para revisão manual

## Suporte

- Área do aluno: https://volynx.world/dev-journey/student/
- Checklist: https://volynx.world/dev-journey/checklist/
- Suporte: https://volynx.world/support/

## Próximos passos

Ao concluir o Pro, o próximo nível é o **Bundle**, que libera Blocos 4-5, deploy/certificação e o Arsenal Kit.

---

VOLYNX • Building a Smarter Future
