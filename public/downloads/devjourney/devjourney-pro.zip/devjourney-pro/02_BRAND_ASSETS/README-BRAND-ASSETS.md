# Brand assets — Dev Journey Pro Track

Atualizado em 2026-05-06.

Esta pasta substitui os assets antigos do pacote Social e passa a ser a pasta oficial de marca em todos os ZIPs do Dev Journey.

## Arquivos inclusos

- volynx-logo-2026.png: VOLYNX 2026 logo
- dev-journey-logo-2026.png: Dev Journey 2026 course mark
- volynx-wordmark-2026.png: VOLYNX 2026 wordmark
- volynx-icon-mark-2026.webp: VOLYNX 2026 lightweight icon mark

## Como usar

- Use o logo Dev Journey em capas, README, hero do projeto final e apresentações do curso.
- Use o logo VOLYNX 2026 quando quiser sinalizar que o projeto faz parte do ecossistema.
- Use a wordmark em cabeçalhos largos, splash screens ou páginas de apresentação.
- Use o icon mark quando precisar de algo menor, como favicon, selo, avatar ou detalhe de card.

## Cuidados

- Nao distorça a proporção dos assets.
- Nao coloque a wordmark sobre fundo claro sem contraste.
- Nao revenda, redistribua ou empacote esses assets como biblioteca independente.
- Em projeto de portfólio, mantenha a marca como referência educacional do Dev Journey, não como se a VOLYNX fosse dona do seu projeto.
