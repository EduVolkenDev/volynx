# Ordem de estudo — Dev Journey Pro Track

Atualizado em 2026-05-06.

## Ordem recomendada — Pro Track

1. Bloco 0: setup completo, conta VOLYNX, GitHub, Node.js LTS e checklist.
2. Blocos 1 e 2: revise fundamentos e use os starters como base.
3. Bloco 3: abra o projeto React com Vite, rode localmente e avance por features pequenas.
4. Publicação: publique o app e atualize README com repo + URL live.
5. Registro: mantenha repo, URL live e evidências prontos para revisão manual.

## Regra principal

Nao marque uma etapa como pronta porque voce "leu". Marque quando existir algo funcionando na tela, com repo organizado e sem erro no Console.

## Rotina segura por bloco

1. Leia o objetivo do bloco.
2. Abra o starter certo.
3. Rode localmente.
4. Faça uma mudança pequena.
5. Veja funcionar na tela.
6. Faça commit.
7. Atualize README quando tiver algo publicável.
8. Marque o checklist online.

## Onde está cada coisa neste ZIP

- 00_START_HERE/: guias atuais de início, setup, entrega e certificação.
- 01_GLOSSARIOS/: glossários rápidos dos blocos iniciais.
- 02_BRAND_ASSETS/: new-devjourney-asset, digitalpresence e guia de uso.
- 03_VOLYNX_FREE_ICON_PACK/: pack opcional de ícones para site/portfólio.
- PDFs/: materiais do Bloco 0 ao Bloco 3.
- Projetos/Start-Projects/: starters dos blocos iniciais.
- Projetos/Bloco-3-React-App/: starter React incremental com Vite.

## Quando travar

Use a regra dos 20 minutos:

1. Volte um passo.
2. Rode o exemplo original.
3. Compare arquivo por arquivo.
4. Leia o erro no Console/Terminal.
5. Se ainda travar, anote o erro exato e mande no suporte.
